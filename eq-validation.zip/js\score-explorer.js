/* Interactive score explorer for the Norms and scoring section.
   Reads window.EQ_DISTRIBUTION and renders the curve, marker, and readout. */

(function(){
  var D = window.EQ_DISTRIBUTION;
  var n = D.n, MIN = D.min, MAX = D.max, C = D.counts, M = D.m, S = D.s;
  var toScore = function(raw){ return 75 + 10 * (raw - M) / S; };
  var toRaw   = function(sc){ return M + (sc - 75) / 10 * S; };

  var pct = new Array(C.length), below = 0;
  for (var i = 0; i < C.length; i++){ pct[i] = (below + 0.5 * C[i]) / n * 100; below += C[i]; }

  function pctAt(score){
    var idx = toRaw(score) - MIN;
    if (idx <= 0) return 0;
    if (idx >= C.length - 1) return 100;
    var lo = Math.floor(idx), t = idx - lo;
    return pct[lo] + (pct[lo + 1] - pct[lo]) * t;
  }

  var W = 900, H = 340, P = {l:44, r:16, t:26, b:42};
  var X0 = 45, X1 = 100;
  var iw = W - P.l - P.r, ih = H - P.t - P.b;
  var sx = function(s){ return P.l + (s - X0) / (X1 - X0) * iw; };

  var pts = [];
  for (var j = 0; j < C.length; j++){
    var s = toScore(MIN + j);
    if (s < X0 - 2 || s > X1 + 2) continue;
    var acc = 0, wt = 0;
    for (var k = -2; k <= 2; k++){
      var q = j + k;
      if (q < 0 || q >= C.length) continue;
      var ww = 3 - Math.abs(k);
      acc += C[q] * ww; wt += ww;
    }
    pts.push({s:s, v:acc / wt});
  }
  var vmax = 0;
  pts.forEach(function(p){ if (p.v > vmax) vmax = p.v; });
  var sy = function(v){ return P.t + ih - (v / vmax) * ih; };

  var NS = 'http://www.w3.org/2000/svg';
  var svg = document.getElementById('chart');
  function el(t, a){ var e = document.createElementNS(NS, t); for (var k in a) e.setAttribute(k, a[k]); return e; }

  var area = 'M ' + sx(pts[0].s).toFixed(1) + ' ' + (P.t + ih);
  pts.forEach(function(p){ area += ' L ' + sx(p.s).toFixed(2) + ' ' + sy(p.v).toFixed(2); });
  area += ' L ' + sx(pts[pts.length - 1].s).toFixed(1) + ' ' + (P.t + ih) + ' Z';
  var line = 'M ' + pts.map(function(p){ return sx(p.s).toFixed(2) + ' ' + sy(p.v).toFixed(2); }).join(' L ');

  for (var g = X0; g <= X1; g += 5){
    svg.appendChild(el('line', {x1:sx(g), y1:P.t, x2:sx(g), y2:P.t + ih, stroke:'#E4EBF3', 'stroke-width':1}));
    var tx = el('text', {x:sx(g), y:P.t + ih + 21, 'text-anchor':'middle', fill:'#7387A0',
      'font-size':12, 'font-family':'var(--mono)'});
    tx.textContent = g; svg.appendChild(tx);
  }
  var xl = el('text', {x:P.l + iw / 2, y:H - 5, 'text-anchor':'middle', fill:'#4A5B6E', 'font-size':12});
  xl.textContent = 'Overall EQ score'; svg.appendChild(xl);
  var yl = el('text', {x:11, y:P.t + ih / 2, 'text-anchor':'middle', fill:'#4A5B6E', 'font-size':12,
    transform:'rotate(-90 11 ' + (P.t + ih / 2) + ')'});
  yl.textContent = 'Number of people'; svg.appendChild(yl);

  svg.appendChild(el('path', {d:area, fill:'#DCE8F5'}));
  svg.appendChild(el('path', {d:line, fill:'none', stroke:'#4E7FB5', 'stroke-width':2}));
  svg.appendChild(el('line', {x1:P.l, y1:P.t + ih, x2:P.l + iw, y2:P.t + ih, stroke:'#C3D2E4'}));

  var hoverG = el('g', {opacity:0});
  var hl = el('line', {x1:0, y1:P.t, x2:0, y2:P.t + ih, stroke:'#7387A0', 'stroke-width':1, 'stroke-dasharray':'3 3'});
  hoverG.appendChild(hl); svg.appendChild(hoverG);

  var youG = el('g', {});
  var yline = el('line', {x1:0, y1:P.t - 6, x2:0, y2:P.t + ih, stroke:'#00A878', 'stroke-width':2.5});
  var ydot  = el('circle', {cx:0, cy:P.t - 6, r:5, fill:'#00A878'});
  var ytxt  = el('text', {x:0, y:P.t - 14, 'text-anchor':'middle', fill:'#066E4E', 'font-size':12,
    'font-weight':700, 'font-family':'var(--mono)'});
  ytxt.textContent = 'score';
  youG.appendChild(yline); youG.appendChild(ydot); youG.appendChild(ytxt);
  svg.appendChild(youG);

  var tip = document.getElementById('tip');
  var input = document.getElementById('score');
  var l1 = document.getElementById('line1'), l2 = document.getElementById('line2');

  function words(p){
    if (p < 10) return 'Most recent test-takers score higher than this.';
    if (p < 25) return 'This sits below the middle of the current distribution.';
    if (p < 42) return 'This sits a little below the middle of the current distribution.';
    if (p <= 58) return 'This sits right around the middle of the current distribution.';
    if (p < 75) return 'This sits somewhat above the middle of the current distribution.';
    if (p < 90) return 'This sits in the upper quarter of the current distribution.';
    return 'This sits in the top tenth of the current distribution.';
  }

  function setYou(sc){
    sc = Math.min(100, Math.max(20, sc));
    var p = pctAt(sc);
    var x = sx(Math.min(X1, Math.max(X0, sc)));
    yline.setAttribute('x1', x); yline.setAttribute('x2', x);
    ydot.setAttribute('cx', x); ytxt.setAttribute('x', x);
    l1.innerHTML = 'Scores higher than <em>' + p.toFixed(0) + '%</em> of recent test-takers.';
    l2.textContent = words(p);
  }

  function posOf(e){
    var r = svg.getBoundingClientRect();
    var cx = (e.touches ? e.touches[0].clientX : e.clientX) - r.left;
    return X0 + (cx / r.width * W - P.l) / iw * (X1 - X0);
  }
  function hover(e){
    var s = Math.min(X1, Math.max(X0, posOf(e)));
    var r = svg.getBoundingClientRect();
    hoverG.setAttribute('opacity', 1);
    hl.setAttribute('x1', sx(s)); hl.setAttribute('x2', sx(s));
    tip.style.opacity = 1;
    tip.style.left = (sx(s) / W * r.width) + 'px';
    tip.style.top  = (P.t / H * r.height) + 'px';
    tip.textContent = 'score ' + s.toFixed(0) + '  ·  higher than ' + pctAt(s).toFixed(0) + '%';
  }
  svg.addEventListener('mousemove', hover);
  svg.addEventListener('touchstart', hover, {passive:true});
  svg.addEventListener('touchmove', function(e){ hover(e); e.preventDefault(); }, {passive:false});
  svg.addEventListener('mouseleave', function(){ hoverG.setAttribute('opacity', 0); tip.style.opacity = 0; });
  input.addEventListener('input', function(){
    var v = parseFloat(input.value); if (!isNaN(v)) setYou(v);
  });
  setYou(75);

  var marks = [[10, '10% score below'], [25, '25% score below'], [50, 'half score below'],
               [75, '75% score below'], [90, '90% score below']];
  var box = document.getElementById('marks');
  marks.forEach(function(m){
    var lo = X0, hi = 100;
    for (var i = 0; i < 40; i++){
      var mid = (lo + hi) / 2;
      if (pctAt(mid) < m[0]) lo = mid; else hi = mid;
    }
    var d = document.createElement('div');
    d.className = 'mark';
    d.innerHTML = '<b>' + ((lo + hi) / 2).toFixed(0) + '</b><span>' + m[1] + '</span>';
    box.appendChild(d);
  });
})();
